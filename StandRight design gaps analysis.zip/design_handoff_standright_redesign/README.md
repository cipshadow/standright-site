# Handoff: StandRight — Spine &amp; Breath redesign

## Overview

A complete visual redesign of **StandRight** (`dev.cip.standright`), a local-only Android
posture-habit app. It replaces the current Material 3 sage theme across every screen and state,
introduces one ownable data primitive (**the Spine**) in place of the progress ring and heat map,
and adds the acknowledgement moment the core action currently lacks.

The redesign is deliberately **drop-in**: the navigation graph, view models, Flows, Room schema,
notification channels, permissions and CSV export are all unchanged. One data-layer addition is
required (a fortnight query — see *Data layer changes*).

**Why it was done:** an audit against Headspace/Calm/Balance found 15 gaps. The largest was that
`lightColorScheme()` was called without the five `surfaceContainer*` roles, so every `Card` and the
`NavigationBar` fell back to Material's *baseline purple* palette (`#F7F2FA`, `#F3EDF7`) — faintly
lilac chrome on a sage canvas. Other findings: one elevation (1dp) on every container so nothing
read as primary; nine tracked-out ALL-CAPS micro-labels fighting the app's gentle copy; a progress
ring encoding only a ratio, so 3-of-4 and 30-of-40 rendered identically; and no feedback whatsoever
when a user answers a check-in.

---

## About the design files

The files in this bundle are **design references created in HTML**. They are prototypes showing
intended look, geometry and motion — **not production code to copy**. There is no Kotlin in them.

The task is to **recreate these designs in the existing Jetpack Compose codebase**, using its
established patterns: `MaterialTheme`, `Card`, `Switch`, `Slider`, `HorizontalPager`,
`AnimatedVisibility`, `Canvas`, `NotificationCompat`. Where this document specifies a hex value,
a dp, or an easing curve, use it exactly. Where it describes a component, build it with the
Compose primitive the codebase already uses for that job.

Two HTML idioms that must be translated rather than transcribed:

| HTML in the mock | Compose equivalent |
| --- | --- |
| `border-radius: 999px` | `CircleShape` (or `RoundedCornerShape(50)`) |
| `border-radius: 32px / 26px / 12px` | `RoundedCornerShape(32.dp / 26.dp / 12.dp)` |
| `box-shadow: 0 4px 12px …, 0 24px 64px …` | `Modifier.shadow()` / `CardDefaults.cardElevation()` — see *Elevation* |
| `radial-gradient(…)` bloom | `Brush.radialGradient` behind the focal object, on the canvas |
| `animation: exhale 4.2s` | `ValueAnimator` / `rememberInfiniteTransition` with `Breathe` token |
| `44px` frame radius | The device bezel in the mock. **Not a token.** Ignore it. |

---

## Fidelity

**High-fidelity.** Final colours, typography, spacing, radii, elevation and motion. Every hex,
dp and easing curve in this README is intended as-is. Recreate pixel-faithfully using the
codebase's existing composables.

Two caveats:

- The mock frames are **390 × 844 px at 1 dp = 1 px**. Real screens vary; every screen must remain
  scrollable (`verticalScroll`) as it is today. Do not pin heights.
- Chart interiors in the mocks are sized to fit the 390 × 844 frame. Treat the **ratios and
  colours** as normative and let the real chart fill its available height.

---

## Design tokens

### Colour — `ui/theme/Color.kt`

**All five `surfaceContainer*` roles must be declared.** This is the single highest-value change in
the document: omitting them is what makes cards and the nav bar render lilac today.

```kotlin
// Canvas & surfaces
val Canvas          = Color(0xFFF6F1EA)  // background, surfaceContainer
val SurfaceRaised   = Color(0xFFFFFDFA)  // surface, surfaceContainerLowest
val SurfaceLow      = Color(0xFFFDF9F3)  // surfaceContainerLow
val Well            = Color(0xFFEFE6DA)  // surfaceContainerHigh — sunken wells
val WellDeep        = Color(0xFFE9DFD0)  // surfaceContainerHighest
val Hairline        = Color(0xFFE4D9C9)  // outlineVariant
val Sand            = Color(0xFFDED3C2)  // inactive switch track, ghost rungs

// Ink
val Ink             = Color(0xFF2A231D)  // onSurface           13.9:1 on Canvas
val Ink2            = Color(0xFF6B5D50)  // onSurfaceVariant     5.4:1 on Canvas
val InkOnDusk       = Color(0xFF2A231D)  // onPrimaryContainer

// Dusk — "straight"
val Dusk            = Color(0xFF93A4CE)  // primaryContainer, rung fill
val DuskDeep        = Color(0xFF6E80AE)  // newest rung, active dot
val DuskInk         = Color(0xFF4A5B8C)  // primary — text & actions  6.2:1 on Canvas

// Semantic — one meaning per hue
val SandSlouch      = Color(0xFFD7C4A8)  // "slouched" data. NEVER red.
val Clay            = Color(0xFFC57E6A)  // the live tilt nudge, and nothing else
val ClayGlow        = Color(0xFFD69684)  // overlay gradient inner stop
val ClayInk         = Color(0xFF8E4A33)  // "glowing now" text        5.1:1 on Well
val Berry           = Color(0xFF8E3B52)  // error — real failures only  7.1:1 on Canvas
val BerryWash       = Color(0xFFF6E7E9)  // error container
val Night           = Color(0xFF251F2C)  // notification shade / dark surfaces
```

**Semantic rules — these fix two live bugs:**

1. **Clay is only ever the live tilt nudge.** `SettingsScreen.kt` currently paints the live angle
   readout and "Would flash now" in `colorScheme.error`, which tells the user something is broken
   when nothing is. Move it to `ClayInk`.
2. **Berry is only ever a real failure.** The one place it appears is
   `settings_tilt_unavailable` ("Tilt detection isn't available on this device") and the CSV export
   failure. Nothing in the *data set* is rendered in an error colour.
3. **`tertiaryContainer` no longer does double duty.** Today the streak chip and the
   missing-permissions card are both `tertiaryContainer`, so on first run Home shows two identical
   beige cards meaning opposite things. The permissions card becomes `Dusk`.

### Typography — `ui/theme/Type.kt`

Two families. Display is **Outfit** (geometric, round bowls); text is **Figtree**.

| Role | Family | Size | Weight | Tracking | Used for |
| --- | --- | --- | --- | --- | --- |
| displayLarge | Outfit | 88.sp | 300 | −0.04em | The live angle readout `52°` only |
| displayMedium | Outfit | 56.sp | 300 / 600 | −0.035em | Screen heroes ("seven / of nine") |
| displaySmall | Outfit | 44.sp | 300 / 600 | −0.035em | Page titles |
| headlineMedium | Outfit | 32.sp | 300 / 600 | −0.03em | History title, shade clock |
| titleLarge | Outfit | 24.sp | 600 | −0.02em | Card values, section heads |
| titleMedium | Outfit | 20.sp | 500 | 0 | Button labels |
| bodyLarge | Figtree | 17.sp | 400 / 600 | 0 | Row labels, body copy |
| bodyMedium | Figtree | 15.sp | 400 / 500 | 0 | Captions, sub-labels |
| bodySmall | Figtree | 13.sp | 500 | 0 | Axis and weekday labels |

**Rules:**

- **Sentence case everywhere. Zero positive tracking.** All nine ALL-CAPS labels in `strings.xml`
  (`STREAK`, `DISMISSED`, `HEAD-UP`, `REMINDERS`, `DAYS`, `HOURS`, `HOW OFTEN`,
  `STRAIGHT-UP MODE`, `PERMISSIONS`, `ABOUT`) become sentence case. Caps-plus-tracking at 12sp is
  admin-console grammar and contradicts copy that says "no rush, no harm".
- **Use weight contrast within a single line.** Outfit 300 against 600 is the primary expressive
  device: "*how's your* **back** *right now?*", "**seven** / *of nine*". Never set a whole display
  line in one weight.
- Minimum text size is 13.sp. Nothing smaller carries words.

### Spacing — new file `ui/theme/Spacing.kt`

Six values on a 4-grid. The current build uses 10/12/14/16/18/20/24/32 with no rule.

```kotlin
object Space {
    val xs   = 4.dp   // inside a pill
    val sm   = 8.dp   // icon to label
    val md   = 12.dp  // between rows, between cards
    val lg   = 20.dp  // inside a card
    val gutter = 24.dp // screen edge — every screen, including onboarding
    val xl   = 40.dp  // between groups
}
```

Delete 14, 18, 26 and the 32.dp onboarding padding. Gutter is **24.dp on every screen**
(onboarding currently uses 26/32).

### Shape — `ui/theme/Shape.kt`

Four radii. The current file declares 8/12/16/24/28 and only ever consumes 16.

```kotlin
val Shapes = Shapes(
    extraSmall = RoundedCornerShape(12.dp),  // chips, chart cells
    small      = RoundedCornerShape(26.dp),  // nested card inside a card
    medium     = RoundedCornerShape(32.dp),  // the default card
    large      = RoundedCornerShape(32.dp),
    extraLarge = CircleShape                 // anything tappable
)

/** inner = outer − padding. A 32 container with 6 padding holds 26. */
fun nested(outer: Dp, padding: Dp) = RoundedCornerShape((outer - padding).coerceAtLeast(0.dp))
```

Also delete the hardcoded `RoundedCornerShape(13.dp)` in `DayOfWeekPicker.kt`. Day chips become
`CircleShape`.

### Elevation

**There are no drop shadows inside the app.** Depth is fill plus one bloom. This is a deliberate
departure from the current build, where every container is a bare `Card {}` at 1dp with a
pure-black shadow — which greys the warmth out from under every card and makes the hero metric
weigh exactly the same as the legal disclaimer.

| Plane | Treatment | Used for |
| --- | --- | --- |
| E0 sunken | `Well` `#EFE6DA` fill, no border, no shadow | day-chip wells, slider tracks, the tilt preview |
| E1 flat card | `SurfaceRaised` `#FFFDFA`, optional 1.dp `Hairline` border | the default: all cards, all rows |
| E2 focal | `SurfaceRaised` + a radial `Dusk` bloom **on the canvas behind it** | one per screen, max |

The bloom: `Brush.radialGradient(listOf(Dusk.copy(alpha=.32f), Dusk.copy(alpha=.07f), Color.Transparent), ...)`
at ~400 dp, animated with the `Breathe` token. It sits on the **canvas**, not inside the card —
the current `HeroCard` puts a 45%-alpha halo inside a `Card`, where it is clipped by the card's own
bounds.

If a `Card` shadow is unavoidable for a given composable, tint it — `rgba(42,35,29,0.06)` — never
pure black.

---

## The Spine — the one new primitive

**New file: `ui/Spine.kt`.** One composable, `drawRoundRect` in a loop. It replaces both
`ProgressRing` (in `HomeScreen.kt`) and `HeatMapCanvas.kt`, and both can then be deleted.

### Concept

One check-in, one rung. Rungs stack **bottom-up**, so the column literally stands taller the more
the user notices their posture. It is the app's launcher mark (three vertebrae) drawn upright.

This fixes the ring's core failure: `ratio = straight / answered` hides volume, so 3-of-4 and
30-of-40 render identically. The Spine shows volume (height), quality (fill) and chronology
(order) simultaneously.

### Encoding

| Rung state | Fill | Geometry |
| --- | --- | --- |
| Sitting tall | `Dusk` `#93A4CE` | full height |
| Slouching | `SandSlouch` `#D7C4A8` | full height |
| Dismissed / let pass | `Sand` `#DED3C2` | **3 dp hairline** — it still counts as a rung |
| The newest rung | `DuskDeep` `#6E80AE` | height + 6 dp, animated in with `Reward` |
| Not yet answered (ghost) | `#E4D9C9` → `#F1EADE` fading upward | full height |

Treating a dismissal as a deliberate answer that still occupies a rung is the visual form of
"ignoring it is a fine answer too". Keep it.

### Internal geometry — deliberately NOT on the layout grid

Rung height and gap are drawn properties of the primitive, like stroke width. Forcing them onto
the 4 dp layout grid is what made the first draft of the chart illegible.

| Call site | Rung height | Gap | Rung width |
| --- | --- | --- | --- |
| Home hero (vertical) | 14 dp (newest 20) | 6 dp | 52 dp |
| Noted screen | 16 dp (newest 24) | 8 dp | 88 dp |
| Onboarding page 1 | 18 dp | 8 dp | 96 dp |
| History day column | 10 dp | 3 dp | fills 1/7 of row width |
| Notification `largeIcon` | 7 dp | 3 dp | 22 dp |
| Nav bar icon | 4 dp | 2 dp | 18 dp |

Minimum legible ratio is roughly **3.5:1 width-to-height** — below that a rung reads as a dot and
the primitive stops working. Axis and weekday labels are 13.sp.

### Call sites (five)

1. `HomeScreen.kt` — hero, replacing `ProgressRing`
2. `HistoryScreen.kt` — 14 day columns, replacing `HeatMapCanvas`
3. `NotificationFactory.kt` — rendered to a Bitmap for `largeIcon`
4. `MainActivity.kt` — the "Today" nav icon
5. `OnboardingScreen.kt` — the welcome mark, replacing the launcher icon in a 160 dp circle

---

## Screens

All 15 surfaces below map to a state branch that exists in the source today, except **Noted**,
which is new.

### 1 · Onboarding — `ui/onboarding/OnboardingScreen.kt`

`HorizontalPager` (4 pages), pager dots and Back/Continue/Start row all **kept as-is
structurally**. Dots: active `22 × 6 dp` `DuskInk`, inactive `6 × 6 dp` `Sand`, `CircleShape`,
animated with `Settle`. Buttons: 56 dp tall, `CircleShape`, primary is `Ink` fill with
`SurfaceRaised` label at 20.sp; Back is a text button in `DuskInk`.

**Page 1 — Welcome.** Canvas `#F6F1EA` with a breathing `Dusk` bloom. Centred: a 4-rung Spine
(96 dp wide, 18 dp rungs, 8 dp gaps — bottom `DuskDeep`, middle two `Dusk`, top `Sand`), then
56.sp display at 44 dp above it: "*sit taller,*" (300) / "**gently.**" (600). Body 17.sp `Ink2`.
Copy unchanged: `onboarding_welcome_title`, `onboarding_welcome_body`.

**Page 2 — What it does.** Title 44.sp: "*what the* **phone does**". Three rows, each a
`SurfaceRaised` 32 dp card, 20 dp padding, 12 dp gap, 12 dp icon-to-text. Leading element is a
44 dp `CircleShape` `Well` disc containing the **numeral** 1/2/3 at 20.sp Outfit 600 — replacing
`Icons.Filled.Notifications` / `TouchApp` / `Layers`. Numeral 3 is `ClayInk`, because step three
*is* the glow. Rows stagger in with `Settle` at 60 ms — the existing `Settle.STAGGER_MS`.
Privacy note: `Well` fill, 32 dp radius, 20 dp padding, 15.sp `Ink`.
**Change:** it is currently `surfaceVariant.copy(alpha = 0.6f)` — an alpha-blended container whose
contrast depends on what is behind it. Make it a solid fill.

**Page 3 — Schedule.** Kept as three controls; this is the one screen where setting the schedule
once is the job. Same `DayOfWeekPicker` mask write, same `RangeSlider(0f..1439f)`, same interval
slider. Presentation: day chips are `CircleShape` in an `Well` well with 5 dp padding
(`nested`), selected = `Ink` fill + `SurfaceRaised` letter; unselected = **no fill**, `Ink2`
letter. Slider tracks 8 dp `CircleShape`, active `Dusk`, thumbs 24 dp `Ink` circles. The value
moves out of a caps label into 24.sp Outfit 600 on the card's right edge ("09:00 – 21:00",
"every 30 min").

**Page 4 — Permissions.** Granted card = `Dusk` fill, solid 12 dp `Ink` dot, no action. Not
granted = `SurfaceRaised`, 12 dp dot outlined 2 dp `Ink2`, plus a 44 dp `CircleShape` `Ink`
"Allow" button. **Delete the `Text("✓")` glyph** but keep its
`semantics { contentDescription = perm_state_granted }`.

### 2 · Home / Today — `ui/HomeScreen.kt`

Three branches, all present in the file today.

**a. Populated (`answered > 0`).** Top row: a `Well` `CircleShape` day pill ("tuesday") left,
"nine asks so far" 15.sp `Ink2` right. Centre, filling the flex space: the **Spine on the left**
(52 dp wide, 14 dp rungs, 6 dp gaps, labelled "09:00" at the base and "now" at the top, both
13.sp) with the hero text right — 56.sp "**seven**" (600) / "*of nine*" (300), then 17.sp `Ink2`
sentence, then three inline stat pills.

The three `StatChip` **cards** become inline `Well` `CircleShape` pills — number first at 20.sp
Outfit 600, label after at 15.sp `Ink2`, 4 dp between: "**4** days in a row", "**2** let pass",
"**3** nudges" (the last in `ClayInk`). The current chips put a 12sp caps label *above* a 20sp
value, so the label shouts over the content.

Bottom: the toggle group as an `Well` 32 dp container with 4 dp padding holding a
`SurfaceRaised` 26 dp card (`nested`) for the first row. Switches: on = `Ink` track +
`Dusk` thumb; off = `Sand` track + `SurfaceRaised` thumb. Snooze row keeps its own 15-second
clock; the action is a 44 dp `CircleShape` outlined button.

Nav bar: `SurfaceRaised` with a 1 dp `Hairline` top border, 76 dp tall. Icons built from the
primitive — Today is a 3-rung Spine, History is three ascending pills, Settings is a ring.
Active label 13.sp 600 `Ink`, inactive 500 `Ink2`.

**b. First run (`ratio == null`, permissions missing).** Hero is a **ghost Spine** — four rungs
fading upward `#E4D9C9` → `#F1EADE` — beside 44.sp "*no check-ins* / **yet today**" and
"The first ask lands around ten. One tap and the bottom rung fills in." It shows what will fill
and in which direction. Today this branch renders an en-dash inside an empty circle.

Permissions card: **`Dusk` fill** (not `tertiaryContainer`), holding three `SurfaceRaised`
26 dp rows with dot + label + action. Copy unchanged.

**c. Paused (`snoozedUntilMillis > now`).** The whole canvas desaturates — `#F1EDE6` canvas,
`#E4DED3` wells, `#FBF8F2` surfaces — and the Spine drops to 50% opacity, so the user can tell at
arm's length that the app is quiet. Hero becomes 44.sp "*paused until* / **17:08**". Resume is an
`Ink` filled pill. Transition uses the new `Quiet` token. Today this state is one line of body
text.

### 3 · Noted — **new**: `ui/NotedScreen.kt` + `CheckInReceiver`

The payoff. Answering a check-in currently writes a row and dismisses a notification — no
confirmation, no motion, nothing. This is a **1.6 s transient**, launched by `CheckInReceiver`
after the answer is persisted, dismissible by tapping anywhere, finishing itself.

Centred 88 dp-wide Spine; the newest rung lands with `Reward` (700 ms, one overshoot) while every
rung below it **holds still**. Then 56.sp Outfit 600 "noted", and 17.sp `Ink2`: "That's seven
today, and four days in a row. Nothing else to do." A `Well` pill at the bottom reads "back to
what you were doing". Breathing `Dusk` bloom behind.

### 4 · History — `ui/HistoryScreen.kt`

Three cards matching the three existing charts, plus export.

**Fortnight (replaces the heat map).** Two rows of seven, weekday-aligned, labelled "last week"
and "this week" (13.sp). Each day is a Spine column: 10 dp rungs, 3 dp gaps, filling 1/7 of the
row. Days outside the active window dim the **column** to 45% — never the label, which stays
`Ink2` at full strength. Weekday letters 13.sp beneath.
Stacking two weeks on aligned columns means this Tuesday reads against last Tuesday, which a
single 14-wide row cannot show.

**Time of day.** 24 hourly bars, `CircleShape`, stacked `Dusk` over `SandSlouch`, 3 dp gaps,
2 dp between the two segments. Axis 00/06/12/18/23 at 13.sp.

**Head-down time.** 8 weekly bars, `CircleShape`, 8 dp gaps. The six older weeks are a muted
`#E4D2C6`; **only the two most recent are full-strength `Clay`**.

**Export.** 56 dp `CircleShape` outlined button, `DuskInk` label at 20.sp. Two transient states
above it, one at a time: *preparing* = `Well` pill with an animated three-bar spinner (the History
nav icon animating); *failed* = `BerryWash` pill, 12 dp `Berry` dot, `Berry` label. Copy unchanged
(`history_export_preparing`, `history_export_failed`). CSV logic untouched.

**Empty states — `ui/charts/ChartEmptyState.kt`.** Change the signature from `(icon, message)` to
take a **ghost-preview slot**: each empty card shows its own chart at 45% opacity in `Sand`, so the
user learns the shape before having data. Card 1 adds "Your first rung is one tap away."; card 3
gains the action it was missing — a 48 dp "Turn it on" pill. Existing copy retained beneath.
Nothing is set in `outline` `#78847E`, which is ~3.2:1 and fails AA.

### 5 · Settings — `ui/SettingsScreen.kt`

Six caps section labels become sentence-case 17.sp `Ink` headings. **Every slider keeps its exact
range, step count and write.**

**Reminders.** Days picker as page 3. Minimum-gap slider keeps `INTERVAL_STEPS_MINUTES`
(1/5/10/30/60/180/360/720/1440) with step labels 1m/30m/1h/6h/24h at 13.sp. Active window keeps
`RangeSlider(0f..1439f)` and `roundToHalfHour`. Wind-down keeps its switch. Values at 24.sp on the
card's right edge.

**Straight-up mode.** `TiltGauge` is **deleted** — the quarter-arc needle and the 15–85 slider both
go. In their place, a 230 dp `Well` panel carrying the **live `Breathe` glow at the overlay's exact
stops**, with the live angle at 88.sp Outfit 300 in the centre and "seven past your line —
glowing now" at 17.sp `ClayInk`. You set the threshold by tipping the phone until the edges glow:
the setting demonstrates itself.

Below it a 0°–90° axis, both ends labelled 13.sp: track `CircleShape` 8 dp, `Dusk` up to the
threshold, then a **`Clay` sliver for the overshoot**, then `Sand`. A 4 × 20 dp `Ink` notch marks
the threshold, labelled "45° your line". The axis must always show the threshold as a marked point
on the scale — an unmarked fill implies the threshold is the maximum.

Sensor-missing message: `BerryWash` card, 12 dp `Berry` dot, `Berry` 17.sp title. This is the only
true error on the screen.

**Permissions & About.** Rows become dot + label + **state word** + action, so the scan line runs
label → state → action. Today the tick/cross glyph sits *before* the label and the button after, so
the scan breaks in the middle. Rows are 12/20 dp padding inside a 4 dp-padded `SurfaceRaised`
container, divided by 1 dp `Well` rules. Version footer moves off `outline` (3.2:1, fails AA) to
`Ink2` at 15.sp, 5.4:1.

### 6 · Notifications — `service/NotificationFactory.kt`, `DailySummaryWorker.kt`

The surface most users see most days, and currently the least designed: a default-styled
notification with two **null-icon** text actions.

- **Check-in reminder.** Add a `largeIcon` — a 5-rung Spine rendered from today's counts
  (22 dp wide, 7 dp rungs, 3 dp gaps) — and one line of context under the title
  ("Seven tall out of nine today."). Two real actions. Channel, silence, `IMPORTANCE` unchanged.
- **Daily summary.** Existing copy plus the encouragement line. **Drop the `answered == 0` early
  return** — `summary_fresh_start` ("Noticing counts, whatever the number.") already exists for
  exactly that day and currently never fires. The day a user most needs encouragement is the day
  they get none.
- **Service notification** (`notif_service_title`) and **paused notification**
  (`notif_paused_title` / `_body`) — restyled only.

### 7 · Overlay — `overlay/OverlayController.kt`

**Do not redesign this.** It is already the best thing in the app: a radial gradient, transparent
at centre, 24% alpha at 58%, 57% at the edge, breathing over 4200 ms with `REVERSE` and an
accelerate-decelerate curve, edges only, suppressed during calls.

The change is to **promote it to a token** that Settings, onboarding page 2 and every bloom read
from, instead of a period duplicated as an unused `Breathe.PERIOD_MS` constant. Its colours
(`#D69684` → `#C57E6A`) move into `Color.kt`.

---

## Interactions & motion — `ui/theme/Motion.kt`

Your two existing families are well judged — reflective surfaces settle, actionable ones respond.
**Keep both exactly as they are.** Add three.

| Token | Duration | Easing | Used for |
| --- | --- | --- | --- |
| `Settle` *(kept)* | 500 ms | `CubicBezier(.2, 0, 0, 1)`, 60 ms stagger | cards arriving, rungs drawing bottom-up on open, chart bars rising, onboarding rows, pager dot widening |
| `Respond` *(kept)* | 200 ms | `CubicBezier(.3, 0, .6, 1)` | toggles, day chips, slider thumbs and their readout, Grant/Allow presses, tab switches |
| `Reward` *(new)* | 700 ms | `CubicBezier(.22, 1, .36, 1)`, one overshoot, no bounce | a rung landing on Noted; the streak pill incrementing. **Nothing else, ever** |
| `Breathe` *(promoted)* | 4200 ms | accelerate-decelerate, `REVERSE` | the overlay; every hero bloom; the tilt preview; onboarding page 2 step 3 |
| `Quiet` *(new)* | 900 ms | `CubicBezier(.4, 0, .2, 1)` | entering/leaving pause; wind-down starting; reminders switched off. Colour and saturation only — nothing moves |

**Two rules:**

1. **Never animate the Spine's existing rungs.** When a new one lands, the ones below it hold
   still. The column is a record, and a record that shuffles every time you add to it stops being
   trustworthy.
2. **Respect the system reduce-motion setting.** `Reward` becomes a 200 ms fade, `Breathe` holds at
   its midpoint alpha, `Quiet` snaps. The overlay must never pulse for someone who asked it not to.

---

## State management

No new state. Every screen reads the same Flows it does today:

- `app.stats.todayOverview()` → hero counts, streak, dismissed, tilt flashes
- `app.settings.settings` → toggles, schedule, threshold, snooze, wind-down
- `rememberPermissionStatus()` → the permissions rows and the Home warning card

**New local state, two items:**

- `NotedScreen` — a 1.6 s visibility timer plus the index of the landing rung, so `Reward` fires
  once.
- `HistoryScreen` — the export transient (`idle` / `preparing` / `failed`), which today is a
  fire-and-forget toast.

`SnoozeRow` keeps its own 15-second ticking clock. Do not replace it with a recomposition trigger —
it is what lets the row flip back on its own when the pause ends.

---

## Data layer changes

**Exactly one, and it is required.**

`StatsRepository` needs a **fortnight query** (14 days of per-day check-in lists, each with
timestamp, answer and dismissal flag) beside the existing ten-week aggregate. Seventy narrow
columns cannot hold a legible rung, so the heat map becomes a two-week Spine.

Keep the ten-week aggregate — the CSV export uses it and is otherwise unaffected.

Everything else in this document is presentation only.

---

## Accessibility

- Contrast: every text colour above clears WCAG AA on its stated ground. Two current failures are
  fixed: `outline` `#78847E` (~3.2:1) on the version footer and empty-state icons, and the
  alpha-blended onboarding privacy panel.
- **Keep every accessibility string in `strings.xml` unchanged** — `chart_heatmap_desc`,
  `chart_hourly_desc`, `chart_weekly_desc`, `settings_tilt_gauge_desc`, `perm_state_granted`,
  `perm_state_not_granted`. The tilt gauge description survives its visual replacement.
- The Spine needs a `contentDescription` giving counts, not shape: "Seven of nine check-ins
  straight today."
- Minimum touch target 44 dp; all buttons here are 44–68 dp.
- Honour reduce-motion as above.

---

## Deliberately unchanged

The three-tab navigation, every view model and Flow, the Room schema, all three notification
channels, the silent-and-no-vibration policy, the call-suppression logic, the CSV export, and every
accessibility string. **Nothing here needs a new permission, a new sensor, or a migration.**

The copy is unchanged throughout — every string in the mocks is one the app already ships. "No
rush, no harm", "Ignoring it is a fine answer too", "handy mid-ride". Do not let the redesign sand
this off; the visuals were built up to meet it.

---

## Suggested order

| # | Files | Why | Est. |
| --- | --- | --- | --- |
| 01 | `Color.kt` | Kills the lavender across every card and the nav bar at once | 1 h |
| 02 | `Type.kt`, `Shape.kt`, new `Spacing.kt` | Everything below depends on the scales | 1 d |
| 03 | new `ui/Spine.kt` | Five call sites depend on it; deletes `ProgressRing` + `HeatMapCanvas` | 3 d |
| 04 | `strings.xml` | Nine caps labels to sentence case | ½ d |
| 05 | `HomeScreen.kt` | Three state branches | 2 d |
| 06 | `SettingsScreen.kt` | Deletes `TiltGauge`; two colour-semantics fixes | 2 d |
| 07 | `HistoryScreen.kt` + `StatsRepository` | The one data change | 2 d |
| 08 | `OnboardingScreen.kt` | Four pages | 2 d |
| 09 | `NotificationFactory.kt` | `largeIcon` + context line | 1 d |
| 10 | new `NotedScreen.kt` + `CheckInReceiver` | The payoff — largest behavioural gap | 2 d |
| 11 | `DailySummaryWorker.kt`, `Motion.kt` | Drop the early return; add three tokens | ½ d |

Do 01 first regardless — it is an hour and it changes every screen.

---

## Open questions for the product owner

1. **The nav.** Three tabs were kept so this drops in without a refactor. Arguably History is the
   same page scrolled down and Settings is a sheet, which would make the app a single page. That is
   a real IA change, not a restyle — it was left as the owner's call.
2. **Dark mode.** The current build has a `darkColorScheme`; this redesign specifies light only, per
   the brief. The notification shade and the evening recap show the palette works after dark, but a
   real dark theme is its own pass, not an inversion.

---

## Assets

**None.** No illustration, no photography, no icon set, no font licensing beyond two Google Fonts
(Outfit, Figtree — both SIL Open Font License, bundle as `res/font`).

Every graphic in the design is drawn from rounded rectangles, circles and gradients — the Spine,
the nav icons, the numerals, the blooms, the glow. This was a deliberate constraint: the app should
be recognisable without an illustration budget.

The existing launcher icon is retained. `ic_launcher_foreground` is no longer used inside the app
(onboarding page 1 shows the Spine instead).

---

## Files in this bundle

| File | Contents |
| --- | --- |
| `StandRight App - Full Redesign.dc.html` | **The primary reference.** All 15 surfaces, the token spec, the motion spec with live animation demos, and the file-by-file mapping. Open in a browser. |
| `StandRight Design Teardown.dc.html` | The original 15-gap audit against the current build, with every screen recreated 1 dp = 1 px from source. Useful for *why* each change was made. |
| `StandRight Direction - Sway.dc.html` | An earlier direction (arcs rather than rungs) and a gap-by-gap scorecard. Context only — **not** the design to build. |

The HTML files are self-contained apart from Google Fonts; open them directly. They are wide
(2280–2400 px) — scroll horizontally, or zoom out to see a whole section.
